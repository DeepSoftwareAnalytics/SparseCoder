import json
#java python go php javascript ruby
for file_name in ["train", "valid", "test"]:
    total_data = []
    with open("all/{}.jsonl".format(file_name), "w") as fw:
        for lang in ["java", "python", "go", "php", "javascript", "ruby"]:
            with open("{}/{}.jsonl".format(lang,file_name)) as f:
                for line in f:
                    data = json.loads(line)
                    fw.write(json.dumps(data) + "\n")
